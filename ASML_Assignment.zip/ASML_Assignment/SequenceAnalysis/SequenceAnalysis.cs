﻿using System;
using System.Linq;
using OptionsNS;

namespace SequenceAnalysis
{
    public class SequenceAnalysis : IOptions
    {
        /*
         * Find the uppercase words in a string, provided as input, and order all characters in these words alphabetically.
            Input: "This IS a STRING"
            Output: "GIINRSST"
        */
        string IOptions.RunOption(string input)
        {
            Console.WriteLine("Please provide an input string");
            string inputString = input;
            if (inputString == "") // Input may be sent via parameter for test automation.
                inputString = Console.ReadLine();
            var UpperCasesWithOther = inputString.Where(x => x >= 'A' && x <= 'Z').OrderBy(x => x).ToArray();
            string result = String.Concat(UpperCasesWithOther);
            Console.WriteLine(String.Concat("Output : ", result));
            return result;
        }
    }
}
