using NUnit.Framework;
using OptionsNS;
using System;


namespace TestAllOptions
{
    public class Tests
    {
        [TestCase("SumOfMultiple", "999999999999999999999999999999999", "233333333333333333333333333333332166666666666666666666666666666669")]
        [TestCase("SumOfMultiple", "10", "23")]
        [TestCase("SumOfMultiple", "15", "45")]
        [TestCase("SumOfMultiple", "45", "450")]
        [TestCase("SequenceAnalysis", "This IS a STRING", "GIINRSSTT")]
        [TestCase("SequenceAnalysis", "Test case for lower case string", "T")]
        [TestCase("SequenceAnalysis", "FEDABC", "ABCDEF")]
        [TestCase("SequenceAnalysis", "123456789", "")]
        public void TestMethodForAllOptions(String testName, String input, String expectedValue)
        {
            Options option = new(testName);
            string result = option.RunOption(input);
            Assert.AreEqual(result, expectedValue);
        }
    }
}


