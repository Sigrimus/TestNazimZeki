﻿using System;
using System.Numerics;
using OptionsNS;

namespace SumOfMultiple
{

    public class SumOfMultiple : IOptions
    {
        //sum of all natural numbers that are a multiple of 3 or 5 below a limit provided as input.
        string IOptions.RunOption(string input)
        {
            String output = "";
            Console.WriteLine("Please provide a input limit");
            string inputNumber = input;
            if (inputNumber == "")  // Input may be sent via parameter for test automation.
            {
                inputNumber = Console.ReadLine();
            }

            if (BigInteger.TryParse(inputNumber, out BigInteger naturalNumber))
            {
                output = String.Concat(FindSumofDivisor(naturalNumber, 3) + FindSumofDivisor(naturalNumber, 5) - FindSumofDivisor(naturalNumber, 15));
                Console.WriteLine(String.Concat("Output : ", output));
            }
            else
            {
                Console.WriteLine("Invalid number");
            }
            return output;
        }
        private static BigInteger FindSumofDivisor(BigInteger naturalNumber, int divisor)
        {
            BigInteger diff = naturalNumber % divisor;
            if (diff == 0) diff = divisor; 
            BigInteger maxDividend = naturalNumber - diff;
            BigInteger numberOfDividends = maxDividend / divisor;
            BigInteger totalSum = divisor * (numberOfDividends * (numberOfDividends + 1)) / 2;
            return totalSum;
        }
    }
}
