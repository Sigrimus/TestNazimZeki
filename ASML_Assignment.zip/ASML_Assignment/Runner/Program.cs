﻿using OptionsNS;
using System.Configuration;

Dictionary<string, string> optionList = new();
const string exitOption = "0";
string optionChosed;

do
{
    PrintAllOptions();
    optionChosed = Console.ReadLine();
    if (optionList.ContainsKey(optionChosed))
    {
        Options options = new (optionList[optionChosed]);
        options.RunOption();
    }
    else if(optionChosed != exitOption)
    {
        Console.WriteLine("Incorrect option!");
        Console.WriteLine("Please try again...");
    }
}
while (optionChosed != exitOption);


void PrintAllOptions()
{
    Console.WriteLine("");
    Console.WriteLine($"{exitOption} for Exit");
    var appSettings = ConfigurationManager.AppSettings;
   
    foreach (var key in appSettings.AllKeys)
    {
        Console.WriteLine($"{key} for {appSettings[key]}");
        if (!optionList.ContainsKey(key))
            optionList.Add(key, appSettings[key]);
    }
    Console.WriteLine("Please choose an option...");
}