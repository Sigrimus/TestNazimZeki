Author			: Nazim Zeki Ugur
Date			: 24/02/2022
Framework		: .Net 6 
Ide				: Visual Studio 22

Instructions

1. Please use below link to install .NET Runtime 6.0.2 before run the test.
https://dotnet.microsoft.com/en-us/download/dotnet/6.0

For Compile Purposes

1. Please use below link to install SDK 6.0.200.
https://dotnet.microsoft.com/en-us/download/dotnet/6.0

2. Please use below link to install Visual Studio 2022.
https://visualstudio.microsoft.com/vs/


For Test Purposes

1.You can run the Runner.exe under ..\ASML_Assignment\Runner\bin\Debug\net6.0 or 
..\ASML_Assignment\Runner\bin\Release\net6.0 without compiling.
2.You can use Nunit and TestAllOptions.dll to run the tests.

