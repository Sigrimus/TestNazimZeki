﻿using System.Reflection;

namespace OptionsNS
{
    public class Options
    {
        public IOptions IOptions { get; set; }
        public Options(string optionName)
        {
            var objectType = GetTypeFromAssembly(optionName);
            IOptions = Activator.CreateInstance(objectType) as IOptions;
        }
        
        private static Type? GetTypeFromAssembly(string assemblyName)
        {
            //Should be cached
            Assembly assembly = Assembly.LoadFrom(string.Concat(assemblyName, ".dll"));
            return assembly?.GetType(string.Concat(assemblyName,".", assemblyName), false, true);
        }
        public string RunOption(string input = "")
        {
            return IOptions.RunOption(input);
        }
    }
}